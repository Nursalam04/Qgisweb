var wms_layers = [];


        var lyr_GoogleTrafficRoadmap_0 = new ol.layer.Tile({
            'title': 'Google Traffic Roadmap',
            'type':'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://mt0.google.com/vt?lyrs=m@159000000,traffic|seconds_into_week:-1&style=3&x={x}&y={y}&z={z}'
            })
        });

        var lyr_OpenStreetMap_1 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            'type':'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'http://a.tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });

        var lyr_GoogleSatellite_2 = new ol.layer.Tile({
            'title': 'Google Satellite',
            'type':'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://mt0.google.com/vt/lyrs=s&x={x}&y={y}&z={z}'
            })
        });
var format_BatasAdministrasi_3 = new ol.format.GeoJSON();
var features_BatasAdministrasi_3 = format_BatasAdministrasi_3.readFeatures(json_BatasAdministrasi_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_BatasAdministrasi_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_BatasAdministrasi_3.addFeatures(features_BatasAdministrasi_3);
var lyr_BatasAdministrasi_3 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_BatasAdministrasi_3, 
                style: style_BatasAdministrasi_3,
                popuplayertitle: 'Batas Administrasi',
                interactive: true,
                title: '<img src="styles/legend/BatasAdministrasi_3.png" /> Batas Administrasi'
            });
var format_Bentik_4 = new ol.format.GeoJSON();
var features_Bentik_4 = format_Bentik_4.readFeatures(json_Bentik_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Bentik_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Bentik_4.addFeatures(features_Bentik_4);
var lyr_Bentik_4 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Bentik_4, 
                style: style_Bentik_4,
                popuplayertitle: 'Bentik',
                interactive: true,
    title: 'Bentik<br />\
    <img src="styles/legend/Bentik_4_0.png" /> Batuan<br />\
    <img src="styles/legend/Bentik_4_1.png" /> Ganggang<br />\
    <img src="styles/legend/Bentik_4_2.png" /> Hamparan Lamun<br />\
    <img src="styles/legend/Bentik_4_3.png" /> Pasir<br />\
    <img src="styles/legend/Bentik_4_4.png" /> Pecahan Karang<br />\
    <img src="styles/legend/Bentik_4_5.png" /> Terumbu Karang<br />\
    <img src="styles/legend/Bentik_4_6.png" /> <br />' });
var format_PelabuhanLabuhanBajo_5 = new ol.format.GeoJSON();
var features_PelabuhanLabuhanBajo_5 = format_PelabuhanLabuhanBajo_5.readFeatures(json_PelabuhanLabuhanBajo_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_PelabuhanLabuhanBajo_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_PelabuhanLabuhanBajo_5.addFeatures(features_PelabuhanLabuhanBajo_5);
var lyr_PelabuhanLabuhanBajo_5 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_PelabuhanLabuhanBajo_5, 
                style: style_PelabuhanLabuhanBajo_5,
                popuplayertitle: 'Pelabuhan Labuhan Bajo',
                interactive: true,
                title: '<img src="styles/legend/PelabuhanLabuhanBajo_5.png" /> Pelabuhan Labuhan Bajo'
            });

lyr_GoogleTrafficRoadmap_0.setVisible(true);lyr_OpenStreetMap_1.setVisible(true);lyr_GoogleSatellite_2.setVisible(false);lyr_BatasAdministrasi_3.setVisible(true);lyr_Bentik_4.setVisible(true);lyr_PelabuhanLabuhanBajo_5.setVisible(true);
var layersList = [lyr_GoogleTrafficRoadmap_0,lyr_OpenStreetMap_1,lyr_GoogleSatellite_2,lyr_BatasAdministrasi_3,lyr_Bentik_4,lyr_PelabuhanLabuhanBajo_5];
lyr_BatasAdministrasi_3.set('fieldAliases', {'KECAMATAN': 'KECAMATAN', });
lyr_Bentik_4.set('fieldAliases', {'class': 'class', });
lyr_PelabuhanLabuhanBajo_5.set('fieldAliases', {'Name': 'Name', 'descriptio': 'descriptio', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMo': 'altitudeMo', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', });
lyr_BatasAdministrasi_3.set('fieldImages', {'KECAMATAN': 'TextEdit', });
lyr_Bentik_4.set('fieldImages', {'class': 'TextEdit', });
lyr_PelabuhanLabuhanBajo_5.set('fieldImages', {'Name': 'TextEdit', 'descriptio': 'TextEdit', 'timestamp': 'TextEdit', 'begin': 'TextEdit', 'end': 'TextEdit', 'altitudeMo': 'TextEdit', 'tessellate': 'TextEdit', 'extrude': 'TextEdit', 'visibility': 'TextEdit', 'drawOrder': 'TextEdit', 'icon': 'TextEdit', });
lyr_BatasAdministrasi_3.set('fieldLabels', {'KECAMATAN': 'inline label - visible with data', });
lyr_Bentik_4.set('fieldLabels', {'class': 'no label', });
lyr_PelabuhanLabuhanBajo_5.set('fieldLabels', {'Name': 'no label', 'descriptio': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMo': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', });
lyr_PelabuhanLabuhanBajo_5.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});